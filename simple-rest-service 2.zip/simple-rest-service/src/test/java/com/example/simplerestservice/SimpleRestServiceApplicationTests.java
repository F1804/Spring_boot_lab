package com.example.simplerestservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleRestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
